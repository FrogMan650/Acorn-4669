;------------------------------------------------------------------------------
; Filename: tt_check_configuration.cnc
; Description: Check to ensure TT is correctly configured before use
; Notes:
; Requires: CNC12 V4.99 REV 6
; Revision Date: 09 MAR 2023
; Please see TB300 or the following link for tips on writing custom macros.
; https://www.centroidcnc.com/centroid_diy/downloads/acorn_documentation/centroid_cnc_macro_programming.pdf
;------------------------------------------------------------------------------
; Parameters:
; #9011 : Probe Input
; #9014 : Fast Probing Rate
; #9015 : Slow Probing Rate
; #9044 : TT Input
; #9071 : TT Height
;
; System Variables:
;
; PLC Variables:
;
; User Variables:
; #33001 : TT Input
; #33002 : Fast Probing Rate
; #33003 : Slow Probing Rate
;
;------------------------------------------------------------------------------
IF #50001                        ;Prevent lookahead from parsing past here
IF #4201 || #4202 THEN GOTO 1000 ;Skip macro if graphing or searching

N100                             ;Insert your code between N100 and N1000
;Check for PLC input
;If check if either parameter 11 or parameter 44 are > 0
IF !#9011 && !#9044 THEN M225 #110 "No PLC input has been configured for the Tool Touch Off device.\nPlease enter the PLC input for the Tool Touch Off device in parameter 11\nPress Cycle Cancel to end job now."
IF #50001                         			;Force lookahead to stop processing
IF !#9011 && !#9044 THEN GOTO 100

;Check if current plc input set in parameter 44 is between 1 & 8 if it is less <= 50000
IF [#9044 > 8] && [#9044 <= 50000] THEN M225 #110 "The PLC input entered into parameter 44 in invalid.\nPlease enter a value of between 1 and 8 into parameter 44\nPress Cycle Cancel to end job now."
IF #50001                         			;Force lookahead to stop processing
IF [#9044 > 8] && [#9044 <= 50000] THEN GOTO 100
IF #50001                       			;Force lookahead to stop processing

;If parameter 44 is != 0 && < 50000, check if current plc input set in parameter 44 is between 1 & 8
IF [[#9044 != 0] && [#9044 < 50000]] && [[#9044 < 1] || [#9044 > 8]] THEN M225 #110 "The PLC input entered into parameter 44 in invalid.\nPlease enter a value of between 1 and 8 into parameter 44\nPress Cycle Cancel to end job now."
IF #50001                         			;Force lookahead to stop processing
IF [[#9044 != 0] && [#9044 < 50000]] && [[#9044 < 1] || [#9044 > 8]] THEN GOTO 100
IF #50001

;If parameter 44 is != 0 && >= 50000, check if current plc input set in parameter 44 is between 50001 & 50008
IF [[#9044 != 0] && [#9044 >= 50000]] && [[#9044 < 50001] || [#9044 > 50016]] THEN M225 #110 "The PLC input entered into parameter 44 in invalid.\nPlease enter a value of between 1 and 8 into parameter 44\nPress Cycle Cancel to end job now."
IF #50001                         			;Force lookahead to stop processing
IF  [[#9044 != 0] && [#9044 >= 50000]] && [[#9044 < 50001] || [#9044 > 50016]] THEN GOTO 100
IF #50001                         			;Force lookahead to stop processing

;If parameter 44 = 0 && parameter 11 < 50000, check if current plc input set in parameter 11 is between 1 & 8 if it is less <= 50000
IF [#9044 == 0] && [#9011 < 50000] && [[#9011 < 1] || [#9011 > 8]] THEN M225 #110 "The PLC input entered into parameter 11 in invalid.\nPlease enter a value of between 1 and 8 into parameter 11\nPress Cycle Cancel to end job now." 
IF #50001                         			;Force lookahead to stop processing
IF [#9044 == 0] && [#9011 < 50000] && [[#9011 < 1] || [#9011 > 8]] THEN GOTO 100

;If parameter 44 = 0 && parameter 11 >= 50000, check if current plc input set in parameter 11 is between 50001 & 50008
IF [#9044 == 0] && [#9011 >= 50000] && [[#9011 < 50001] || [#9011 > 50016]] THEN M225 #110 "The PLC input entered into parameter 11 in invalid.\nPlease enter a value of between 1 and 8 into parameter 11\nPress Cycle Cancel to end job now." 
IF #50001                         			;Force lookahead to stop processing
IF [#9044 == 0] && [#9011 >= 50000] && [[#9011 < 50001] || [#9011 > 50016]] THEN GOTO 100
IF #50001                         			;Force lookahead to stop processing

;Check that touch off device height has been set
IF #9071 == 0 && [#9043 and 1] THEN M225 #110 "The height for the tool touch off device has not been set in parameter 71.\nPlease measure the height of your tool touch off device and enter it parameter 71\nPress Cycle Cancel to end job now."
IF #50001                         			;Force lookahead to stop processing
IF #9071 == 0 && [#9043 and 1] THEN GOTO 100

IF #50001                         			;Force lookahead to stop processing
IF #9044 != 0 THEN #33001 = #9044             ;Set TT1 input to value in parameter 44 if it's not = to 0.
IF #50001                         			;Force lookahead to stop processing
IF #9044 == 0 THEN #33001 = #9011             ;Set TT1 input to value in parameter 11 if parameter 44 = 0.
IF #50001                         			;Force lookahead to stop processing

IF #33001 > 50000 THEN #33001 = #33001 - 50000
IF #50001                         			;Force lookahead to stop processing

;Check/set probing rates
IF [#9014 == 0] && [#4006 == 20] THEN #33002 = 10             ;If fast probing rate = 0, set to default 10"/min
IF #50001                         			;Force lookahead to stop processing
IF [#9014 != 0] && [#4006 == 20] THEN #33002 = #9014          ;If fast probing rate != 0, set to value in #9014
IF #50001                         			;Force lookahead to stop processing

IF [#9014 == 0] && [#4006 == 21] THEN #33002 = 254      		;If fast probing rate = 0, set to default 254mm/min
IF #50001                         			;Force lookahead to stop processing
IF [#9014 != 0] && [#4006 == 21] THEN #33002 = #9014    		;If fast probing rate != 0, set to value in #9014
IF #50001                         			;Force lookahead to stop processing

IF [#9015 == 0] && [#4006 == 20] THEN #33003 = 1        		;If slow probing rate = 0, set to default 1"/min
IF #50001 
IF [#9015 != 0] && [#4006 == 20] THEN #33003 = #9015			;If slow probing rate != 0, set to value in #9015
IF #50001									;Force lookahead to stop processing	
IF [#9015 == 0] && [#4006 == 21] THEN #33003 = 25.4        	;If slow probing rate = 0, set to default 25.4 mm/min
IF #50001                         			;Force lookahead to stop processing
IF [#9015 != 0] && [#4006 == 21] THEN #33003 = #9015        	;If slow probing rate != 0, set to value in #9015
IF #50001                         			;Force lookahead to stop processing

N1000                            ;End of Macro